# Custom-TextBox-2--Rounded-Placeholder
How to create a rounded text box with a placeholder, C# and WindowsForm
<h2>VIDEO TUTORIAL:</h2>
<a href="https://youtu.be/3wP6QqjiCCo" target="_blank">
  <img src="https://rjcodeadvance.com/wp-content/uploads/2021/06/Custom-TextBox-FULL-CSharp-WinForm.png"/>
</a>
